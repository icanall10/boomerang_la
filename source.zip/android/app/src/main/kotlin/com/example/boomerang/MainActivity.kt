package com.example.boomerang

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
