# Run

- firebase login
- flutterfire configure
